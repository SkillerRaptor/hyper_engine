//
// Copyright (c) 2023-2024, SkillerRaptor
//
// SPDX-License-Identifier: MIT
//

pub use glam::*;
